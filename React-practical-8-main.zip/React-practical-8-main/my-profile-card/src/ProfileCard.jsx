import React from "react";
import "./ProfileCard.css"; // Import CSS for styling

function ProfileCard({ name, photo, bio, role, location }) {
  return (
    <div className="profile-card">
      <img src={photo} alt={name} className="profile-pic" />
      <h2>{name}</h2>
      <h4>{role}</h4>
      <p className="location">{location}</p>
      <p className="bio">{bio}</p>
    </div>
  );
}

export default ProfileCard;
