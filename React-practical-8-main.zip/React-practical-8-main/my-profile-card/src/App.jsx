import React from "react";
import ProfileCard from "./ProfileCard";

function App() {
  return (
    <div className="app-container">
      <ProfileCard
        name="Raj Soni"
        photo="/src/assets/profile.jpg" // Replace with actual photo URL
        role="Aspiring Web Developer"
        location="Vadodara, India"
        bio="I love solving problems with code, building cool projects, and continuously learning. Passionate about JavaScript, React, and exploring full-stack development!"
      />
    </div>
  );
}

export default App;
